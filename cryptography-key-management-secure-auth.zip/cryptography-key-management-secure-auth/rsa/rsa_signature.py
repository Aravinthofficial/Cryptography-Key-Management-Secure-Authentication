from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def generate_rsa_keys():
    """Generate an RSA 2048-bit private/public key pair."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    return private_key, private_key.public_key()


def sign_message(private_key, message: str) -> bytes:
    """Create an RSA-PSS/SHA-256 digital signature."""
    return private_key.sign(
        message.encode("utf-8"),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )


def verify_signature(public_key, message: str, signature: bytes) -> bool:
    """Verify an RSA-PSS/SHA-256 signature."""
    try:
        public_key.verify(
            signature,
            message.encode("utf-8"),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH,
            ),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        return False


if __name__ == "__main__":
    private_key, public_key = generate_rsa_keys()

    message = "This message is digitally signed."
    signature = sign_message(private_key, message)

    print("=== RSA-2048 Digital Signature Demo ===")
    print("Signature:", signature.hex())
    print("Original message valid:", verify_signature(public_key, message, signature))

    modified_message = "This message was modified."
    print(
        "Tampered message valid:",
        verify_signature(public_key, modified_message, signature),
    )
