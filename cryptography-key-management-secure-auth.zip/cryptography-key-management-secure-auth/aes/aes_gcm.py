import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def generate_key() -> bytes:
    """Generate a random 256-bit AES key."""
    return AESGCM.generate_key(bit_length=256)


def encrypt(key: bytes, plaintext: str):
    """Encrypt plaintext with AES-256-GCM using a fresh random nonce."""
    aes = AESGCM(key)
    nonce = os.urandom(12)  # 96-bit nonce recommended for GCM
    ciphertext = aes.encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce, ciphertext


def decrypt(key: bytes, nonce: bytes, ciphertext: bytes) -> str:
    """Decrypt and authenticate AES-256-GCM ciphertext."""
    aes = AESGCM(key)
    plaintext = aes.decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")


if __name__ == "__main__":
    key = generate_key()
    message = "This is a secret message."

    nonce, ciphertext = encrypt(key, message)

    print("=== AES-256-GCM Demo ===")
    print("Key:", key.hex())
    print("Nonce:", nonce.hex())
    print("Ciphertext:", ciphertext.hex())

    decrypted = decrypt(key, nonce, ciphertext)
    print("Decrypted:", decrypted)
    print("Round-trip successful:", decrypted == message)

    # Demonstrate authentication failure after tampering.
    tampered = bytearray(ciphertext)
    tampered[0] ^= 1

    try:
        decrypt(key, nonce, bytes(tampered))
        print("Tampered ciphertext accepted: UNEXPECTED")
    except Exception:
        print("Tampered ciphertext rejected: PASS")
