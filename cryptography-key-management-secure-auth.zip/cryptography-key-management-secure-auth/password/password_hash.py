import bcrypt


def hash_password(password: str) -> bytes:
    """Hash a password using bcrypt with a random salt."""
    return bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt(),
    )


def verify_password(password: str, hashed_password: bytes) -> bool:
    """Verify a password against a bcrypt hash."""
    return bcrypt.checkpw(
        password.encode("utf-8"),
        hashed_password,
    )


if __name__ == "__main__":
    password = "MySecurePassword123!"

    hashed_password = hash_password(password)

    print("=== bcrypt Password Hashing Demo ===")
    print("Hash:", hashed_password.decode("utf-8"))
    print("Correct password:", verify_password(password, hashed_password))
    print("Wrong password:", verify_password("WrongPassword", hashed_password))
