# Cryptography, Key Management & Secure Authentication

## Overview

This project demonstrates secure cryptographic implementations in Python:

- AES-256-GCM authenticated encryption and decryption
- RSA 2048-bit key generation and digital signatures
- bcrypt password hashing with salting and work factor
- HMAC-SHA256 message authentication
- Secure key/secret storage and rotation best practices

> Educational project. Do not use demo secrets or hard-coded credentials in production.

## Project Structure

```text
cryptography-key-management-secure-auth/
├── README.md
├── requirements.txt
├── .gitignore
├── aes/
│   └── aes_gcm.py
├── rsa/
│   └── rsa_signature.py
├── password/
│   └── password_hash.py
├── hmac/
│   └── hmac_demo.py
└── docs/
    └── SECURITY_BEST_PRACTICES.md
```

## Requirements

- Python 3.9+
- `cryptography`
- `bcrypt`

## Installation

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Linux/macOS:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run the demos

### AES-256-GCM

```bash
python aes/aes_gcm.py
```

Demonstrates:
- 256-bit AES key generation
- Random 12-byte nonce
- Authenticated encryption
- Successful decryption
- Tampered ciphertext rejection

### RSA Digital Signature

```bash
python rsa/rsa_signature.py
```

Demonstrates:
- RSA 2048-bit key pair generation
- SHA-256 with RSA-PSS signing
- Signature verification
- Tampered message rejection

### bcrypt Password Hashing

```bash
python password/password_hash.py
```

Demonstrates:
- bcrypt password hashing
- Random salt
- Password verification
- Wrong-password rejection

### HMAC-SHA256

```bash
python hmac/hmac_demo.py
```

Demonstrates:
- Secure random HMAC secret
- HMAC-SHA256 generation
- Constant-time verification with `compare_digest`
- Tampered-message rejection

## Security Best Practices

See:

```text
docs/SECURITY_BEST_PRACTICES.md
```

Key rules:
- Never commit passwords, API keys, private keys, or `.env` files.
- Use a secret manager or protected environment configuration.
- Never reuse an AES-GCM nonce with the same key.
- Protect RSA private keys.
- Use bcrypt/Argon2id for password storage rather than reversible encryption.
- Rotate secrets/keys when required and immediately after suspected compromise.

## Expected Evidence

The repository provides source code and runnable terminal demonstrations for:

| Requirement | Implementation |
|---|---|
| AES-256 authenticated encryption | `aes/aes_gcm.py` |
| RSA 2048 digital signature | `rsa/rsa_signature.py` |
| bcrypt password hashing | `password/password_hash.py` |
| HMAC-SHA256 | `hmac/hmac_demo.py` |
| Key storage and rotation | `docs/SECURITY_BEST_PRACTICES.md` |

## License

Educational use.
