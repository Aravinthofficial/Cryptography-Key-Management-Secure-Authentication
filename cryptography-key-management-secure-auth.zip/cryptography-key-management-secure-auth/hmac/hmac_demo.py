import hashlib
import hmac
import secrets


def generate_secret() -> bytes:
    """Generate a 256-bit HMAC secret."""
    return secrets.token_bytes(32)


def create_hmac(secret: bytes, message: str) -> str:
    """Create an HMAC-SHA256 digest."""
    return hmac.new(
        secret,
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def verify_hmac(secret: bytes, message: str, received_hmac: str) -> bool:
    """Verify HMAC using constant-time comparison."""
    expected_hmac = create_hmac(secret, message)
    return hmac.compare_digest(expected_hmac, received_hmac)


if __name__ == "__main__":
    secret = generate_secret()
    message = "Important API request"

    generated_hmac = create_hmac(secret, message)

    print("=== HMAC-SHA256 Demo ===")
    print("HMAC:", generated_hmac)
    print("Original message valid:", verify_hmac(secret, message, generated_hmac))
    print(
        "Tampered message valid:",
        verify_hmac(secret, "Modified request", generated_hmac),
    )
