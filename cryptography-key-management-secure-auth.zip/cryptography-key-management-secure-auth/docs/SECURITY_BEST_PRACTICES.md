# Security Best Practices

## 1. Secret Storage

Never hard-code production passwords, API keys, encryption keys, or tokens in source code.

Prefer:
- Environment variables for simple deployments
- A dedicated secrets manager for production
- OS-level permissions and encrypted storage
- Least-privilege access controls

Never commit `.env`, private keys, or credentials to GitHub.

## 2. AES-256-GCM

AES-256-GCM provides confidentiality and authentication.

Rules:
- Generate keys with a cryptographically secure random generator.
- Use a fresh unique nonce for every encryption under the same key.
- Never reuse a GCM nonce with the same key.
- Store the nonce with the ciphertext; the nonce does not need to be secret.
- Treat authentication/decryption failures as security failures.

## 3. RSA Private Keys

RSA 2048-bit keys are used here for demonstration.

Rules:
- Keep private keys confidential.
- Share public keys only where required.
- Protect private-key files with appropriate OS permissions.
- Do not commit private keys to GitHub.
- Rotate/revoke keys when compromise is suspected.

## 4. Password Storage

Passwords should not be stored in plaintext or with reversible encryption.

Use a dedicated password hashing algorithm such as:
- bcrypt
- Argon2id
- scrypt

Each password should have a unique salt. bcrypt generates the salt automatically.

The work factor should be chosen according to current application performance and security requirements.

## 5. HMAC

HMAC provides message authentication when both parties share a secret.

Rules:
- Keep the HMAC secret confidential.
- Generate secrets using a cryptographically secure random generator.
- Use SHA-256 or another approved cryptographic hash.
- Verify using constant-time comparison such as `hmac.compare_digest()`.

## 6. Key Rotation

A practical rotation process:

1. Generate a new key securely.
2. Store the new key in the secret-management system.
3. Start using the new key for new operations.
4. Support the previous key temporarily when old data must still be read or verified.
5. Re-encrypt or re-sign data where appropriate.
6. Retire and revoke the old key.
7. Record the rotation event.

Rotate immediately if a key is suspected to be compromised.

## 7. GitHub Security Checklist

Before `git push`, verify that the repository contains no:

- Passwords
- API keys
- Access tokens
- Private RSA keys
- AES production keys
- `.env` files containing secrets
- Database credentials
- Cloud credentials

Use `.gitignore` and secret scanning where available.

## 8. Production Note

The scripts in this repository are educational demonstrations. Production systems should also consider secure key storage, access control, audit logging, key lifecycle management, dependency updates, secure error handling, and organizational security requirements.
